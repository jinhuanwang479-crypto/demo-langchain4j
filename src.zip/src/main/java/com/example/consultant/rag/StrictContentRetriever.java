package com.example.consultant.rag;

import com.example.consultant.config.AiRagProperties;
import com.example.consultant.config.TenantContextHolder;
import com.example.consultant.utils.UserContextUtil;
import dev.langchain4j.data.document.Metadata;
import dev.langchain4j.data.embedding.Embedding;
import dev.langchain4j.data.segment.TextSegment;
import dev.langchain4j.model.embedding.EmbeddingModel;
import dev.langchain4j.model.output.Response;
import dev.langchain4j.rag.content.Content;
import dev.langchain4j.rag.content.ContentMetadata;
import dev.langchain4j.rag.content.retriever.ContentRetriever;
import dev.langchain4j.rag.query.Query;
import dev.langchain4j.store.embedding.EmbeddingMatch;
import dev.langchain4j.store.embedding.EmbeddingSearchRequest;
import dev.langchain4j.store.embedding.EmbeddingSearchResult;
import dev.langchain4j.store.embedding.EmbeddingStore;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

public class StrictContentRetriever implements ContentRetriever {

    private static final Logger log = LoggerFactory.getLogger(StrictContentRetriever.class);

    private final EmbeddingStore<TextSegment> embeddingStore;
    private final EmbeddingModel embeddingModel;
    private final AiRagProperties aiRagProperties;

    public StrictContentRetriever(EmbeddingStore<TextSegment> embeddingStore,
                                  EmbeddingModel embeddingModel,
                                  AiRagProperties aiRagProperties) {
        this.embeddingStore = embeddingStore;
        this.embeddingModel = embeddingModel;
        this.aiRagProperties = aiRagProperties;
    }

    @Override
    public List<Content> retrieve(Query query) {
        Response<Embedding> response = embeddingModel.embed(query.text());
        EmbeddingSearchRequest request = new EmbeddingSearchRequest(
                response.content(),
                aiRagProperties.getRetrieval().getMaxResults(),
                aiRagProperties.getRetrieval().getMinScore(),
                null
        );

        EmbeddingSearchResult<TextSegment> searchResult = embeddingStore.search(request);
        List<EmbeddingMatch<TextSegment>> acceptedMatches = new ArrayList<>();

        for (EmbeddingMatch<TextSegment> match : searchResult.matches()) {
            if (!isUsable(match)) {
                continue;
            }
            acceptedMatches.add(match);
            logMatch(query, match);
        }

        if (acceptedMatches.isEmpty()) {
            logEvidenceRejected(query, "知识库中未检索到足够依据");
            return List.of();
        }

        double topScore = acceptedMatches.get(0).score() == null ? 0D : acceptedMatches.get(0).score();
        if (topScore < aiRagProperties.getRetrieval().getAnswerableMinScore()) {
            logEvidenceRejected(query, "检索到了低分片段，但证据不足以支持确定回答");
            return List.of();
        }

        int resultWindow = acceptedMatches.size() > 1 && isScoreClustered(acceptedMatches)
                ? Math.min(3, acceptedMatches.size())
                : Math.min(2, acceptedMatches.size());

        List<Content> contents = new ArrayList<>(resultWindow);
        for (int i = 0; i < resultWindow; i++) {
            contents.add(toContent(acceptedMatches.get(i)));
        }
        return contents;
    }

    private boolean isUsable(EmbeddingMatch<TextSegment> match) {
        if (match == null || match.embedded() == null || match.embedded().text() == null) {
            return false;
        }
        return match.embedded().text().trim().length() >= aiRagProperties.getRetrieval().getMinSegmentLength();
    }

    private boolean isScoreClustered(List<EmbeddingMatch<TextSegment>> matches) {
        double first = matches.get(0).score() == null ? 0D : matches.get(0).score();
        double second = matches.get(1).score() == null ? 0D : matches.get(1).score();
        return Math.abs(first - second) <= 0.03D;
    }

    private Content toContent(EmbeddingMatch<TextSegment> match) {
        TextSegment segment = match.embedded();
        Metadata metadata = segment.metadata() == null ? new Metadata() : segment.metadata().copy();
        String decoratedText = buildSourceHeader(metadata) + segment.text();

        Map<ContentMetadata, Object> contentMetadata = new EnumMap<>(ContentMetadata.class);
        if (match.score() != null) {
            contentMetadata.put(ContentMetadata.SCORE, match.score());
        }
        if (match.embeddingId() != null) {
            contentMetadata.put(ContentMetadata.EMBEDDING_ID, match.embeddingId());
        }
        return Content.from(TextSegment.from(decoratedText, metadata), contentMetadata);
    }

    private String buildSourceHeader(Metadata metadata) {
        String docName = metadata.getString("docName");
        Integer pageNumber = metadata.getInteger("pageNumber");
        if (docName == null && pageNumber == null) {
            return "";
        }
        StringBuilder builder = new StringBuilder("来源：");
        builder.append(docName == null ? "知识库文档" : docName);
        if (pageNumber != null) {
            builder.append(" 第").append(pageNumber).append("页");
        }
        builder.append('\n');
        return builder.toString();
    }

    private void logMatch(Query query, EmbeddingMatch<TextSegment> match) {
        Metadata metadata = match.embedded().metadata();
        log.info("知识检索命中: memoryId={}, tenantId={}, userId={}, docName={}, pageNumber={}, score={}",
                query.metadata() == null ? null : query.metadata().chatMemoryId(),
                TenantContextHolder.getTenantId(),
                UserContextUtil.getUserId(),
                metadata == null ? null : metadata.getString("docName"),
                metadata == null ? null : metadata.getInteger("pageNumber"),
                match.score());
    }

    private void logEvidenceRejected(Query query, String reason) {
        log.info("知识检索拒答: memoryId={}, tenantId={}, userId={}, reason={}",
                query.metadata() == null ? null : query.metadata().chatMemoryId(),
                TenantContextHolder.getTenantId(),
                UserContextUtil.getUserId(),
                reason);
    }
}
