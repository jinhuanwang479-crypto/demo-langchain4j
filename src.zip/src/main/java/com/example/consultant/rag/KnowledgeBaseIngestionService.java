package com.example.consultant.rag;

import com.example.consultant.config.AiRagProperties;
import dev.langchain4j.data.document.Metadata;
import dev.langchain4j.data.embedding.Embedding;
import dev.langchain4j.data.segment.TextSegment;
import dev.langchain4j.model.embedding.EmbeddingModel;
import dev.langchain4j.model.output.Response;
import dev.langchain4j.store.embedding.EmbeddingStore;
import dev.langchain4j.store.embedding.filter.MetadataFilterBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.StreamUtils;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class KnowledgeBaseIngestionService implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(KnowledgeBaseIngestionService.class);

    private final EmbeddingStore<TextSegment> embeddingStore;
    private final EmbeddingModel embeddingModel;
    private final StringRedisTemplate redisTemplate;
    private final PdfKnowledgeDocumentLoader pdfKnowledgeDocumentLoader;
    private final AiRagProperties aiRagProperties;
    private final PathMatchingResourcePatternResolver resourcePatternResolver = new PathMatchingResourcePatternResolver();
    //进行set注入
    public KnowledgeBaseIngestionService(EmbeddingStore<TextSegment> embeddingStore,
                                         EmbeddingModel embeddingModel,
                                         StringRedisTemplate redisTemplate,
                                         PdfKnowledgeDocumentLoader pdfKnowledgeDocumentLoader,
                                         AiRagProperties aiRagProperties) {
        this.embeddingStore = embeddingStore;
        this.embeddingModel = embeddingModel;
        this.redisTemplate = redisTemplate;
        this.pdfKnowledgeDocumentLoader = pdfKnowledgeDocumentLoader;
        this.aiRagProperties = aiRagProperties;
    }

    @Override
    public void run(ApplicationArguments args) throws Exception {
        if (!aiRagProperties.getIngestion().isAutoSyncOnStartup()) {
            return;
        }
        syncKnowledgeBase();
    }

    public synchronized void syncKnowledgeBase() {
        try {
            syncResources(resourcePatternResolver.getResources(aiRagProperties.getResourcePattern()));
        } catch (IOException ex) {
            throw new IllegalStateException("扫描知识库资源失败", ex);
        }
    }

    void syncResources(Resource[] resources) {
        HashOperations<String, Object, Object> hashOperations = redisTemplate.opsForHash();
        Set<String> activeDocIds = new HashSet<>();

        for (Resource resource : resources) {
            String filename = resource.getFilename();
            if (!StringUtils.hasText(filename) || !pdfKnowledgeDocumentLoader.supports(filename)) {
                continue;
            }

            try {
                byte[] bytes = StreamUtils.copyToByteArray(resource.getInputStream());
                String docId = docIdFor(filename);
                String docSha256 = sha256(bytes);
                activeDocIds.add(docId);
                //2️⃣ 对比旧指纹（判断是否变化）  erp:kb:v1:manifest 这个文件夹后面是放 知识库文档的哈希值
                String previousSha256 = asString(hashOperations.get(aiRagProperties.getManifestKey(), docId));
                if (Objects.equals(previousSha256, docSha256)) {
                    log.info("知识库文档未变化，跳过重建: docName={}", filename);
                    continue;
                }

                if (StringUtils.hasText(previousSha256)) {
                    removeDocument(docId);
                }

                List<TextSegment> segments = pdfKnowledgeDocumentLoader.load(bytes, docId, filename, docSha256);
                if (segments.isEmpty()) {
                    log.warn("知识库文档没有可用片段，跳过写入: docName={}", filename);
                    hashOperations.delete(aiRagProperties.getManifestKey(), docId);
                    continue;
                }

                Response<List<Embedding>> response = embeddingModel.embedAll(segments);
                List<String> ids = buildEmbeddingIds(docId, segments);
                embeddingStore.addAll(ids, response.content(), segments);
                hashOperations.put(aiRagProperties.getManifestKey(), docId, docSha256);
                log.info("知识库文档同步完成: docName={}, segments={}", filename, segments.size());
            } catch (IOException ex) {
                throw new IllegalStateException("读取知识库文档失败: " + filename, ex);
            }
        }

        removeStaleDocuments(hashOperations, activeDocIds);
    }

    private void removeStaleDocuments(HashOperations<String, Object, Object> hashOperations, Set<String> activeDocIds) {
        Set<Object> storedDocIds = hashOperations.keys(aiRagProperties.getManifestKey());
        if (storedDocIds == null || storedDocIds.isEmpty()) {
            return;
        }
        for (Object storedDocId : storedDocIds) {
            String docId = asString(storedDocId);
            if (!StringUtils.hasText(docId) || activeDocIds.contains(docId)) {
                continue;
            }
            removeDocument(docId);
            hashOperations.delete(aiRagProperties.getManifestKey(), docId);
            log.info("知识库移除失效文档: docId={}", docId);
        }
    }

    private void removeDocument(String docId) {
        embeddingStore.removeAll(MetadataFilterBuilder.metadataKey("docId").isEqualTo(docId));
    }

    private List<String> buildEmbeddingIds(String docId, List<TextSegment> segments) {
        List<String> ids = new ArrayList<>(segments.size());
        for (int i = 0; i < segments.size(); i++) {
            Metadata metadata = segments.get(i).metadata();
            Integer pageNumber = metadata == null ? null : metadata.getInteger("pageNumber");
            Integer chunkIndex = metadata == null ? null : metadata.getInteger("chunkIndex");
            ids.add(docId + ":" + (pageNumber == null ? 0 : pageNumber) + ":" + (chunkIndex == null ? i : chunkIndex));
        }
        return ids;
    }

    private String docIdFor(String filename) {
        return sha256(filename.toLowerCase(Locale.ROOT).getBytes(StandardCharsets.UTF_8));
    }

    private String sha256(byte[] bytes) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashed = digest.digest(bytes);
            return toHex(hashed);
        } catch (NoSuchAlgorithmException ex) {
            throw new IllegalStateException("当前环境不支持 SHA-256", ex);
        }
    }

    private String toHex(byte[] bytes) {
        return bytesToHex(bytes);
    }

    private String bytesToHex(byte[] bytes) {
        return java.util.stream.IntStream.range(0, bytes.length)
                .mapToObj(i -> String.format("%02x", bytes[i] & 0xff))
                .collect(Collectors.joining());
    }

    private String asString(Object value) {
        return value == null ? null : String.valueOf(value);
    }
}
