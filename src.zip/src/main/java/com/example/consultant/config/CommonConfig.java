package com.example.consultant.config;

import com.example.consultant.rag.StrictContentRetriever;
import dev.langchain4j.community.store.embedding.redis.RedisEmbeddingStore;
import dev.langchain4j.memory.chat.ChatMemoryProvider;
import dev.langchain4j.memory.chat.MessageWindowChatMemory;
import dev.langchain4j.model.embedding.EmbeddingModel;
import dev.langchain4j.rag.content.retriever.ContentRetriever;
import dev.langchain4j.data.segment.TextSegment;
import dev.langchain4j.store.memory.chat.ChatMemoryStore;
import org.springframework.boot.autoconfigure.data.redis.RedisProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import redis.clients.jedis.search.schemafields.NumericField;
import redis.clients.jedis.search.schemafields.SchemaField;
import redis.clients.jedis.search.schemafields.TagField;
import redis.clients.jedis.search.schemafields.TextField;

import java.util.LinkedHashMap;
import java.util.Map;

@Configuration
public class CommonConfig {
    @Bean
    public ChatMemoryProvider chatMemoryProvider(ChatMemoryStore redisChatMemoryStore,
                                                 AiMemoryProperties aiMemoryProperties) {
        return (memoryId) -> MessageWindowChatMemory.builder()
                .maxMessages(aiMemoryProperties.getMaxMessages())
                .id(memoryId)
                .chatMemoryStore(redisChatMemoryStore)
                .build();
    }

    @Bean
    @Primary
    public RedisEmbeddingStore redisEmbeddingStore(RedisProperties redisProperties,
                                                   EmbeddingModel embeddingModel,
                                                   AiRagProperties aiRagProperties) {
        return RedisEmbeddingStore.builder()
                .host(redisProperties.getHost())
                .port(redisProperties.getPort())
                .user(redisProperties.getUsername())
                .password(redisProperties.getPassword())
                .indexName(aiRagProperties.getIndexName())
                .prefix(aiRagProperties.getVectorPrefix())
                .dimension(embeddingModel.dimension())
                .metadataConfig(metadataConfig())
                .build();
    }

    @Bean
    public ContentRetriever contentRetriever(RedisEmbeddingStore redisEmbeddingStore,
                                             EmbeddingModel embeddingModel,
                                             AiRagProperties aiRagProperties) {
        return new StrictContentRetriever(redisEmbeddingStore, embeddingModel, aiRagProperties);
    }

    private Map<String, SchemaField> metadataConfig() {
        Map<String, SchemaField> config = new LinkedHashMap<>();
        config.put("docId", TagField.of("$.docId").as("docId"));
        config.put("docName", TextField.of("$.docName").as("docName"));
        config.put("docSha256", TagField.of("$.docSha256").as("docSha256"));
        config.put("sourceType", TagField.of("$.sourceType").as("sourceType"));
        config.put("pageNumber", NumericField.of("$.pageNumber").as("pageNumber"));
        config.put("chunkIndex", NumericField.of("$.chunkIndex").as("chunkIndex"));
        return config;
    }
}
