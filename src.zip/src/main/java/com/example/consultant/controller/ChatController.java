package com.example.consultant.controller;

import com.example.consultant.aiService.ConsultantService;
import com.example.consultant.service.ConversationService;
import com.example.consultant.utils.UserContextUtil;
import dev.langchain4j.service.tool.ToolExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Flux;
import reactor.core.publisher.FluxSink;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping()
public class ChatController {

    private static final Logger log = LoggerFactory.getLogger(ChatController.class);

    @Autowired
    private ConsultantService consultantService;

    @Autowired
    private ConversationService conversationService;

    /**
     * 聊天接口（流式响应）
     */
    @GetMapping(value = "/chat", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public Flux<String> chat(@RequestParam String memoryId, @RequestParam String message) {
        return Flux.create(emitter -> startStreamingChat(memoryId, message, emitter), FluxSink.OverflowStrategy.BUFFER);
    }

    private void startStreamingChat(String memoryId, String message, FluxSink<String> emitter) {
        try {
            log.info("开始AI对话: memoryId={}, tenantId={}, userId={}",
                    memoryId, UserContextUtil.getTenantId(), UserContextUtil.getUserId());
            consultantService.chat(memoryId, message)
                    .onPartialResponse(emitter::next)
                    .onToolExecuted(toolExecution -> logToolExecution(memoryId, toolExecution))
                    .onCompleteResponse(response -> {
                        log.info("AI 流式响应完成: memoryId={}, finishReason={}",
                                memoryId, response.finishReason());
                        emitter.complete();
                    })
                    .onError(error -> {
                        log.error("AI 流式响应失败: memoryId={}", memoryId, error);
                        emitter.error(error);
                    })
                    .start();
        } catch (Exception ex) {
            log.error("启动 AI 流式响应失败: memoryId={}", memoryId, ex);
            emitter.error(ex);
        }
    }

    private void logToolExecution(String memoryId, ToolExecution toolExecution) {
        log.info("AI 工具调用: memoryId={}, toolName={}, arguments={}",
                memoryId, toolExecution.request().name(), toolExecution.request().arguments());
    }

    @GetMapping("/conversations")
    public Map<String, Object> getConversations() {
        Map<String, Object> result = new HashMap<>();

        try {
            List<Map<String, Object>> conversations = conversationService.getAllConversations();
            result.put("code", 200);
            result.put("result", conversations);
            result.put("success", true);
        } catch (Exception e) {
            result.put("code", 500);
            result.put("message", "获取失败：" + e.getMessage());
            result.put("success", false);
        }
        return result;
    }

    @GetMapping("/conversation/{memoryId}")
    public Map<String, Object> getConversationDetail(@PathVariable String memoryId) {
        Map<String, Object> result = new HashMap<>();
        try {
            List<Map<String, Object>> messages = conversationService.getConversationDetail(memoryId);
            result.put("code", 200);
            result.put("result", messages);
            result.put("success", true);
        } catch (Exception e) {
            result.put("code", 500);
            result.put("message", "获取失败：" + e.getMessage());
            result.put("success", false);
        }
        return result;
    }

    @PostMapping("/conversation/save")
    public Map<String, Object> saveConversation(@RequestBody Map<String, Object> request) {
        Map<String, Object> result = new HashMap<>();
        try {
            String memoryId = (String) request.get("memoryId");
            String message = (String) request.get("message");
            String response = (String) request.get("response");
            List<Map<String, Object>> allMessages = (List<Map<String, Object>>) request.get("allMessages");

            conversationService.saveConversation(memoryId, message, response, allMessages);

            result.put("success", true);
            result.put("memoryId", memoryId);
            result.put("code", 200);
        } catch (Exception e) {
            result.put("code", 500);
            result.put("message", "保存失败：" + e.getMessage());
            result.put("success", false);
        }
        return result;
    }

    @DeleteMapping("/conversation/{memoryId}")
    public Map<String, Object> deleteConversation(@PathVariable String memoryId) {
        Map<String, Object> result = new HashMap<>();
        try {
            boolean success = conversationService.deleteConversation(memoryId);
            result.put("success", success);
            result.put("message", success ? "删除成功" : "删除失败");
            result.put("code", success ? 200 : 500);
        } catch (Exception e) {
            result.put("code", 500);
            result.put("message", "删除失败：" + e.getMessage());
            result.put("success", false);
        }
        return result;
    }

    @DeleteMapping("/conversations/clear")
    public Map<String, Object> clearAllConversations() {
        Map<String, Object> result = new HashMap<>();
        try {
            conversationService.clearAllConversations();
            result.put("success", true);
            result.put("message", "已清空所有历史");
            result.put("code", 200);
        } catch (Exception e) {
            result.put("code", 500);
            result.put("message", "清空失败：" + e.getMessage());
            result.put("success", false);
        }
        return result;
    }
}
