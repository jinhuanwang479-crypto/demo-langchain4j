package com.example.consultant.rag;

import com.example.consultant.config.AiRagProperties;
import dev.langchain4j.data.document.Metadata;
import dev.langchain4j.data.embedding.Embedding;
import dev.langchain4j.data.segment.TextSegment;
import dev.langchain4j.model.embedding.EmbeddingModel;
import dev.langchain4j.model.output.Response;
import dev.langchain4j.rag.content.Content;
import dev.langchain4j.rag.query.Query;
import dev.langchain4j.store.embedding.EmbeddingMatch;
import dev.langchain4j.store.embedding.EmbeddingSearchResult;
import dev.langchain4j.store.embedding.EmbeddingStore;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class StrictContentRetrieverTest {

    @Mock
    private EmbeddingStore<TextSegment> embeddingStore;

    @Mock
    private EmbeddingModel embeddingModel;

    private StrictContentRetriever strictContentRetriever;

    @BeforeEach
    void setUp() {
        strictContentRetriever = new StrictContentRetriever(embeddingStore, embeddingModel, new AiRagProperties());
        when(embeddingModel.embed(any(String.class))).thenReturn(Response.from(Embedding.from(new float[]{1F, 2F})));
    }

    @Test
    void retrieveShouldReturnEmptyWhenTopScoreIsTooLow() {
        EmbeddingMatch<TextSegment> lowScoreMatch = new EmbeddingMatch<>(
                0.70D,
                "embedding-1",
                Embedding.from(new float[]{1F, 2F}),
                TextSegment.from("这是一段足够长但分数不足的内容，用于触发拒答逻辑。", metadata("用户手册.pdf", 8))
        );
        when(embeddingStore.search(any())).thenReturn(new EmbeddingSearchResult<>(List.of(lowScoreMatch)));

        List<Content> contents = strictContentRetriever.retrieve(Query.from("采购流程"));

        assertTrue(contents.isEmpty());
    }

    @Test
    void retrieveShouldDecorateHighConfidenceMatchesWithSource() {
        EmbeddingMatch<TextSegment> highScoreMatch = new EmbeddingMatch<>(
                0.82D,
                "embedding-2",
                Embedding.from(new float[]{1F, 2F}),
                TextSegment.from("采购入库先创建采购订单，再执行入库审核并更新库存。", metadata("用户手册.pdf", 12))
        );
        when(embeddingStore.search(any())).thenReturn(new EmbeddingSearchResult<>(List.of(highScoreMatch)));

        List<Content> contents = strictContentRetriever.retrieve(Query.from("采购入库怎么操作"));

        assertEquals(1, contents.size());
        assertTrue(contents.get(0).textSegment().text().startsWith("来源：用户手册.pdf 第12页"));
        assertTrue(contents.get(0).textSegment().text().contains("采购入库先创建采购订单"));
    }

    private Metadata metadata(String docName, int pageNumber) {
        return new Metadata()
                .put("docName", docName)
                .put("pageNumber", pageNumber)
                .put("sourceType", "pdf");
    }
}
