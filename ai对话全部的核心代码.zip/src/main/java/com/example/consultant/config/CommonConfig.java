package com.example.consultant.config;

import ai.djl.nn.core.Embedding;
import com.example.consultant.aiService.ConsultantService;
import dev.langchain4j.community.store.embedding.redis.RedisEmbeddingStore;
import dev.langchain4j.data.document.Document;
import dev.langchain4j.data.document.DocumentSplitter;
import dev.langchain4j.data.document.loader.ClassPathDocumentLoader;
import dev.langchain4j.data.document.loader.FileSystemDocumentLoader;
import dev.langchain4j.data.document.parser.apache.pdfbox.ApachePdfBoxDocumentParser;
import dev.langchain4j.data.document.splitter.DocumentSplitters;
import dev.langchain4j.memory.ChatMemory;
import dev.langchain4j.memory.chat.ChatMemoryProvider;
import dev.langchain4j.memory.chat.MessageWindowChatMemory;
import dev.langchain4j.model.embedding.EmbeddingModel;
import dev.langchain4j.model.openai.OpenAiChatModel;
import dev.langchain4j.rag.content.retriever.ContentRetriever;
import dev.langchain4j.rag.content.retriever.EmbeddingStoreContentRetriever;
import dev.langchain4j.service.AiServices;
import dev.langchain4j.service.spring.AiService;
import dev.langchain4j.store.embedding.EmbeddingStore;
import dev.langchain4j.store.embedding.EmbeddingStoreIngestor;
import dev.langchain4j.store.embedding.inmemory.InMemoryEmbeddingStore;
import dev.langchain4j.store.memory.chat.ChatMemoryStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.nio.file.FileSystem;
import java.util.List;

@Configuration
public class CommonConfig {
    @Autowired
    private OpenAiChatModel openAiChatModel;
    @Autowired
    private ChatMemoryStore redisChatMemoryStore;
    @Autowired
    private EmbeddingModel embeddingModel;
    @Autowired
    private RedisEmbeddingStore redisEmbeddingStore;
//代理那个service
//    @Bean
//    public ConsultantService consultantService() {
//        ConsultantService service = AiServices.builder(ConsultantService.class)
//                .chatModel(openAiChatModel)
//                .build();
//        return service;
//    }

    //构建会话记忆服务
    @Bean
    public ChatMemory chatMemory() {
        //MessageWindowChatMemory 实现了 ChatMemory 接口，用于存储和管理会话消息
        MessageWindowChatMemory build = MessageWindowChatMemory.builder()
                .maxMessages(20)
                .build();
        return build;
    }
    //构建ChatMemoryProvider对象
//    @Bean
//    public ChatMemoryProvider chatMemoryProvider() {
//         ChatMemoryProvider build = new ChatMemoryProvider(){
//             @Override
//             public ChatMemory get(Object memoryId) {
//                 return MessageWindowChatMemory.builder()
//                        .maxMessages(20)
//                         .id(memoryId)
//                        .build();
//             }
//         };
//        return build;
//    }
    //构建ChatMemoryProvider对象
    @Bean
    public ChatMemoryProvider chatMemoryProvider() {
        //这个实现类只有一个方法，所以可以使用匿名内部类进行直接实现，简写如下：（lambda表达式）
        return (memoryId) -> MessageWindowChatMemory.builder()
                .maxMessages(20)
                .id(memoryId)
                .chatMemoryStore(redisChatMemoryStore)
                .build();
    }


    /**
     *
     * 1.文档加载器，2.文档解析器，3.文档分割器 4.替换向量数据库 5.EmbeddingStore,用于操作向量数据库
     * @return
     */

    //构建向量数据库服务的操作对象（存储）
    @Bean
    public EmbeddingStore store() {
        //1.加载文档进去内存   文档加载器（类路径进行加载）  以及文档解析器（pdfbox）
        List<Document> documents = ClassPathDocumentLoader.loadDocuments("content",new ApachePdfBoxDocumentParser());
//        List<Document> documents = FileSystemDocumentLoader.loadDocuments("C:\\Users\\hspcadmin\\Downloads\\consultant\\consultant\\src\\main\\resources\\content");
        //2.构建向量数据库操作对象  操作的是内存版本的向量数据库
//        InMemoryEmbeddingStore store = new  InMemoryEmbeddingStore();


        //构建文档分割器对象
        DocumentSplitter ds = DocumentSplitters.recursive(500,100);


        //3.构建一个EmbeddingStoreInteger对象，完成对文本数的切割，向量化，存储等操作
        EmbeddingStoreIngestor ingestor = EmbeddingStoreIngestor.builder()
//                .embeddingStore(store)
                .embeddingStore(redisEmbeddingStore)
                .documentSplitter(ds)
                .embeddingModel(embeddingModel)
                .build();
        ingestor.ingest(documents);
        return redisEmbeddingStore;
    }

    //构建向量数据库服务的检索对象（检索）

    /**
     * .minScore(0.5)
     * 含义：最低相似度阈值
     * 作用：只返回相似度 ≥ 0.5 的文档片段
     * 范围：0 ~ 1（越接近 1 越相似）
     * 示例：如果检索到的内容相似度只有 0.4，会被过滤掉
     * .maxResults(3)
     * 含义：最大返回结果数
     * 作用：最多返回 3 个最相关的文档片段给大模型
     * 目的：避免提供过多无关信息，减少 token 消耗
     * @return
     *
    如果回答不够准确：↑ 提高 minScore 或 ↓ 降低 maxResults
    如果回答缺少信息：↓ 降低 minScore 或 ↑ 提高 maxResults
    场景
    minScore   maxResults
    精准回答   0.7 - 0.8   1 - 2
    平衡模式（当前） 0.5   3
    广泛检索   0.3 - 0.4  5 - 10

     *
     */
    @Bean
    public ContentRetriever contentRetriever(/*EmbeddingStore store*/ ){
        return EmbeddingStoreContentRetriever.builder()
                .embeddingStore(redisEmbeddingStore)
                .minScore(0.5)
                .maxResults(3)
                .embeddingModel(embeddingModel)
                .build();
    }
}
