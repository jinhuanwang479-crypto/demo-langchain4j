package com.example.consultant.repository;

import dev.langchain4j.data.message.ChatMessage;
import dev.langchain4j.data.message.ChatMessageDeserializer;
import dev.langchain4j.data.message.ChatMessageSerializer;
import dev.langchain4j.store.memory.chat.ChatMemoryStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
//自己重写的RedisChatMemoryStore，实现了ChatMemoryStore接口，用于存储和获取聊天消息，
// 把这个实现类注入到Spring容器中，交给Store，并在application.yml中配置redis连接信息。
@Repository
public class RedisChatMemoryStore implements ChatMemoryStore {

    @Autowired
    private StringRedisTemplate redisTemplate;

    @Override
    public List<ChatMessage> getMessages(Object memoryId) {
        //从redis中获取会话消息
        String json = redisTemplate.opsForValue().get(memoryId.toString());
        //把json字符串转成list
        List<ChatMessage> list = ChatMessageDeserializer.messagesFromJson(json);
        return list;
    }

    @Override
    public void updateMessages(Object memoryId, List<ChatMessage> list) {
        //更新会话消息
        //1.把list转成json字符串
        String json = ChatMessageSerializer.messagesToJson(list);
        //2.存入redis
        redisTemplate.opsForValue().set(memoryId.toString(), json, 10000, java.util.concurrent.TimeUnit.SECONDS);
    }

    @Override
    public void deleteMessages(Object memoryId) {
        //删除会话消息
        redisTemplate.delete(memoryId.toString());
    }
}
